public class Main {

    public static void main(String[] args) {
       /*
       Creating objects
        */
       Cat thor = new Cat();
       Cat rambo = new Cat();

       /*
       Defining Thor cat
        */
       thor.name = "Thor";
       thor.age = 3;
       thor.breed = "Russian Blue";
       thor.color = "Brown";

       thor.sleep();

       /*
       Defining Rambo cat
        */
       rambo.name = "Rambo";
       rambo.age = 4;
       rambo.breed = "Maine Coon";
       rambo.color = "Brown";

       rambo.play();

       ////////////////////////////////////////////
       
       /*
       Creating objects
        */
        Dog thor = new Dog();
        Dog rambo = new Dog();
 
        /*
        Defining Thor cat
         */
        thor.name = "Thor";
        thor.age = 3;
        thor.breed = "Russian Blue";
        thor.color = "Brown";
 
        thor.sleep();
 
        /*
        Defining Rambo cat
         */
        rambo.name = "Rambo";
        rambo.age = 4;
        rambo.breed = "Maine Coon";
        rambo.color = "Brown";
 
        rambo.play();
    }

}