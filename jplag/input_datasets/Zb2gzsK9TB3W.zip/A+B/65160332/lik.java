import java.util.Scanner ;
public class lik{
	public static void main(String[] args)
{
  Scanner yod = new Scanner(System.in);
  int c ;
  int d;
  c = yod.nextInt();
  d = yod.nextInt();
  System.out.print(c + d);
}
}  