import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
    Scanner input=new Scanner(System.in);
    int a,b,answer;
    a=input.nextInt();
	b=input.nextInt();
    answer=a+b;
    System.out.print(answer);
    }
}