
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int A , B ;
        A = input.nextInt();
        B = input.nextInt();
        System.out.print(A+B);
    }
}

