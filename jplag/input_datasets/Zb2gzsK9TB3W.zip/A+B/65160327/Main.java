/*
Author : Nuttawat Kliewsri
Program : find area of circle
*/
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int a, b, sum;
        a = input.nextInt();
        b = input.nextInt();
        sum = a+b;
        System.out.println(sum);




    }
}