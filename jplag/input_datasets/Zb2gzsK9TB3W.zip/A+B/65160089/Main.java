import java.util.Scanner
        ;
public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);int A,B,plus;

        A = input.nextInt();

        B = input.nextInt();
        plus = A+B ;
        System.out.println(+plus);
    }
}
