import java.util.Scanner ;
public class Main{
  public static void main(String[] args){
    Scanner zayo = new Scanner(System.in);
    int A;
    int B;
    A = zayo.nextInt();
    B = zayo.nextInt();
    System.out.print(A+B);
    }
}