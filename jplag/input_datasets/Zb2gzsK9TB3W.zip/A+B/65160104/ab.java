import java.util.Scanner;

public class ab {
    public static void main(String[]args) {
        Scanner kb = new Scanner(System.in);
        int a = kb.nextInt();
        int b = kb.nextInt();
        System.out.println(a+b);
    }
    }
