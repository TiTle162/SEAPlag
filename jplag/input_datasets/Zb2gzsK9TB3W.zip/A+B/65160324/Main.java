import java.util.Scanner;
public class Main{
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        int a,b,total;
        System.out.print("Input a: ");
        a= input.nextInt();
        System.out.print("Input b: ");
        b= input.nextInt();
        total=a+b;
        System.out.print("total: "+total);






    }
}