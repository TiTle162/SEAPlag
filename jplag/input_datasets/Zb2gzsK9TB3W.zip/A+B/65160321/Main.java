 //Author : Jiraphat Maneewong//
 //Program : Display Value//
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner JRP = new Scanner(System.in);
        int a, b;
        a = JRP.nextInt();
        b = JRP.nextInt();
        System.out.println(a + b);
    }
}
