import java.util.Scanner;
public class HW_01{
    public static void main(String[] args) {
        int a,b;
        Scanner kb = new Scanner(System.in);
        a = kb.nextInt();
        b = kb.nextInt();
        System.out.println(a + b);
    }
}
