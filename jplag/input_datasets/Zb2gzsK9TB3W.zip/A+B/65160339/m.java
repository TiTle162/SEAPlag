import java.util.Scanner ;
public class m{
     public static void main(String[] args)
     {
      Scanner mail = new Scanner(System.in);
       int a ;
       int b;
       a = mail.nextInt();
       b = mail.nextInt();
       System.out.print(a+b);
	}
}
       