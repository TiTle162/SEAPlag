import java.util.Scanner;
public class main{
  public static void main(String[] args){
    Scanner reader = new Scanner(System.in);
    int a = reader.nextInt();
    int b = reader.nextInt();
    System.out.print(a+b);
  }
}