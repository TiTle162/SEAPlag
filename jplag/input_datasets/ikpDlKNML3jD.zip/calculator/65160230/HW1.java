import java.util.Scanner;
public class HW1 {
    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int a = kb.nextInt();
        int b = kb.nextInt();
        System.out.print(a + b);
    }
}
