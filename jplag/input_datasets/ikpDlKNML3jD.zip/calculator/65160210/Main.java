import java.util.Scanner
        ;
public class Main {
    public static void main(String[] args)
    {
        int a,b;
        Scanner kb = new Scanner(System.in);

        a = kb.nextInt();

        b = kb.nextInt();
        System.out.println(a+b);
    }
}

