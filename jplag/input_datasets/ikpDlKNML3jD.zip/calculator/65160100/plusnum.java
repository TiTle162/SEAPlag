import java.util.Scanner;
public class plusnum {
    public static void main (String[] args){
  Scanner A = new Scanner(System.in);
  int B = A.nextInt();
  int C = A.nextInt();
  System.out.println(B+C);

    }
}
