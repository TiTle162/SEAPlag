import java.util.Scanner;
public class PLUS {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);

        int A, B,sum;

        A = input.nextInt();
        B = input.nextInt();
      sum = A+B;

        System.out.print(sum);

    }
}