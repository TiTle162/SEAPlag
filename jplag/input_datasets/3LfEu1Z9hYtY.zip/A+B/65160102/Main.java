import java.util.Scanner;
public class Main {
  public static void main(String[] args) {
    Scanner kb = new Scanner(System.in);
    int n;
    n = kb.nextInt();
    int m;
    m = kb.nextInt();
    System.out.printf("%d\n",n+m);
}
}
