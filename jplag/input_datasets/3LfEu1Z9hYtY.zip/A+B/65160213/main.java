import java.util.Scanner;
public class main {
    public static void main(String[] args) {
        Scanner  input = new Scanner(System.in);
        int a = input.nextInt();
        int b = input.nextInt();
        System.out.print(a+b);
    }
}