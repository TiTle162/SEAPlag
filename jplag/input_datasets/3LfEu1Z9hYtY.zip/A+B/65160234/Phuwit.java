import java.util.Scanner;
public class Phuwit{
    public static void main(String[]ags){
        Scanner input = new Scanner(System.in);
        int a = input.nextInt();
        int b = input.nextInt();
        System.out.print(a+b);
    }
}