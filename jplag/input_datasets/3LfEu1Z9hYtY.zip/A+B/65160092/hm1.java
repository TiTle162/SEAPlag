import java.util.Scanner;

public class hm1{
    public static void main(String[] args) {
        int A,B,sumAB;
        Scanner kb = new Scanner(System.in);
        A = kb.nextInt();
        B = kb.nextInt();
        sumAB = A+B;
        System.out.println(sumAB);
    }
}