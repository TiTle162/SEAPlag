import java.util.Scanner
        ;
public class Main {
    public static void main(String[]args)
    {
        int a,b;
        Scanner jog = new Scanner(System.in);
        
        a = jog.nextInt();
        
        b = jog.nextInt();
        System.out.println(a+b);
    }
}