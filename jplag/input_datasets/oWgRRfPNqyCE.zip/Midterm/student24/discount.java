public class discount {
    private double discount = 0.0;
    
    public discount(double discount){
        this.discount = 0.0;
    }
}