import java.util.Scanner;

public class Test2 {
    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int n = kb.nextInt();
        char[] Type = new char[n];
        String[] arrName = new String[n];
        double[] arrPrice = new double[n];
        double[] arrDiscount = new double[n];
        double min = arrPrice[0];
        double discount = arrDiscount[0];
        String name = arrName[0];

        for (int i = 0; i < n ;i++) {
            Type[i] == 
        }
        System.out.print(name);
        System.out.printf(" %.2f", min);
    }
}
