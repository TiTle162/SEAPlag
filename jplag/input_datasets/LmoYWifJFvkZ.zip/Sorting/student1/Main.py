import module
object = module.Sort()

arr = [-2, 45, 0, 11, -9,88,-97,-202,747]
size = len(arr)
object.selectionSort(arr, size)