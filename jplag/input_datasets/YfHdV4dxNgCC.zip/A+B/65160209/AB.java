import java.util.Scanner;
public class AB {
    public static void main(String[] args) {
        int a , b, sum;
        Scanner kb = new Scanner(System.in);
        a = kb.nextInt();
        b = kb.nextInt();
        sum = a + b;
        System.out.println(sum);

    }
}
