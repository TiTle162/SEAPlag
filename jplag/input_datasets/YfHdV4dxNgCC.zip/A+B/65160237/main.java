import java.util.Scanner;
class main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int A,B,total;
        A = input.nextInt();
        B = input.nextInt();
        total = A + B;
        System.out.println(total);
    }
}
